# Stock-market-virtual-trading
Stock Market virtual Trading System is virtual share market platform where 
this trading system will provide beginners to test the waters of the market without putting any of their money at risk.
On this website traders can buy the shares and they can do some practice before entering into the real market.
Because it’s all fictitious, paper traders don’t have to worry about 
losing money
